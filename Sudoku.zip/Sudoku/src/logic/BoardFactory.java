package logic;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class BoardFactory {

    public int[][] generateBoard(int size) {
        return transformBoardManyTimes(fillTheBoard(size));
    }

    private int[][] fillTheBoard(int size) {
        boolean needShuffle = true;  // если указать false таблица будет иметь всегда один вид 123456789 * 456789123* 789123456 * 234567891 * 567891234 * и т.д.
        int[] firstLine = generateFirstLine(needShuffle, size);
        int[][] board = new int[size][size];
        for (int lineIndex = 0; lineIndex < firstLine.length; lineIndex++) {
            board[lineIndex] = moveByShift(firstLine.clone(), lineIndex, size);
        }

        return board;
    }

    public void printTheBoard(int[][] board) {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }

    private int[] generateFirstLine(boolean needShuffle, int size) {
        int[] firstLine = new int[size];
        for (int i = 0; i < size; i++)
            firstLine[i] = i + 1;
        if (needShuffle) firstLine = shuffleLine(firstLine);
        return firstLine;
    }

    private int[] shuffleLine(int[] firstLine) {
        List<Integer> list = Arrays.asList(Arrays.stream(firstLine).boxed().toArray(Integer[]::new));
        Collections.shuffle(list);
        int[] listArray = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            listArray[i] = list.get(i);
        }
        firstLine = listArray;
        return firstLine;
    }

    private int[] moveByShift(int firstLine[], int lineIndex, int size) {
        int shift = getShift(lineIndex, size);
        while (shift > 0) {
            for (int i = 0; i < firstLine.length - 1; i++) {
                int box = firstLine[i + 1];
                firstLine[i + 1] = firstLine[i];
                firstLine[i] = box;
            }
            shift--;
        }
        return firstLine;
    }

    private int getShift(int lineIndex, int size) {
        final int BLOCK = (int) Math.sqrt(size);
        int regionIndex = lineIndex / BLOCK;
        int lineIndexOnRegion = lineIndex % BLOCK;
        return (BLOCK * lineIndexOnRegion) + regionIndex;
    }

    private int[][] transformBoardManyTimes(int[][] board) {
        final int NUMBERS_OF_TRANSFORMATIONS = 50;
        Random random = new Random();
        BoardTransformer[] boardTransformers = new BoardTransformer[NUMBERS_OF_TRANSFORMATIONS];
        for (int i = 0; i < boardTransformers.length; i++) {
            int choiceTransform = random.nextInt(5) + 1;
            switch (choiceTransform) {
                case 1:
                    boardTransformers[i] = new SwapRows(random);
                    break;
                case 2:
                    boardTransformers[i] = new SwapColumns(random);
                    break;
                case 3:
                    boardTransformers[i] = new SwapRegionsHorizontally(random);
                    break;
                case 4:
                    boardTransformers[i] = new SwapRegionsVertically(random);
                    break;
                case 5:
                    boardTransformers[i] = new SwapRowsAndColumns(random);
                    break;
            }
            boardTransformers[i].transform(board);
        }
        return board;
    }


}




