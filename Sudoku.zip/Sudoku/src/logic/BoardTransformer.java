package logic;

public interface BoardTransformer {

    public void transform(int[][] board);
}
