package logic;

public class HiddenCellBoard {

}
