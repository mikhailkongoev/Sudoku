package logic;

import java.util.Random;

public class SwapRegionsHorizontally extends SwapRegions {

    SwapRegionsHorizontally(Random random) {
        super(random);
    }

    @Override
    public void transform(int[][] board) {
        int length = board.length;
        int regionSize = (int) Math.sqrt(length);
        int[] lineIndices = pickRegions(length);
        int firstRegionIndex = lineIndices[0];
        int secondRegionIndex = lineIndices[1];
        int[][] boardCopy = new int[board.length][board.length];
        int lineRegion = firstRegionIndex * regionSize;
        int lineSecondRegion = secondRegionIndex * regionSize;
        for (int i = 0; i < regionSize; i++) {
            boardCopy[0] = board[lineRegion + i];
            board[lineRegion + i] = board[lineSecondRegion + i];
            board[lineSecondRegion + i] = boardCopy[0];
        }
    }
}
