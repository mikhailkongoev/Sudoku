package main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import logic.BoardFactory;

import java.util.Random;

public class Main extends Application {


    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/start.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("СУДОКУ");
        stage.setResizable(true);
        stage.show();
    }


    public static void main(String[] args) {
     //   Application.launch();   метод, запускающий пользовательский интерфейс
        BoardFactory boardFactory = new BoardFactory();
        int[][] board = boardFactory.generateBoard(9);
        boardFactory.printTheBoard(board);
        System.out.println("");

        Random ran = new Random();
        int row;
        int column;
        boolean decisionResult = true;
        while (decisionResult) {
            row = ran.nextInt(board.length);
            column = ran.nextInt(board.length);
            if (board[row][column] == 0) continue;
            else {
                board[row][column] = 0;
                decisionResult = checkSudoku(board);
            }

            boardFactory.printTheBoard(board);
        }
    }

    public static boolean checkSudoku(int[][] board) {
        boolean result = true;



        return result;
    }

    public static void chekTheCorrectnessOfTable(int[][] board) {
        int size = board.length;
        int line[];
        for (int i = 0; i < size; i++) {
            line = board[i];
            for (int j = 0; j < line.length; j++) {
                for (int z = 0; z < line.length; z++)
                    if (line[j] == line[z] && j != z)
                        System.err.println("Таблица составлена некорректно: числа в строках повторяются");
            }
        }
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                for (int z = 0; z < size; z++)
                    if (board[j][i] == board[z][i] && j != z)
                        System.err.println("Таблица составлена некорректно: числа в столбцах повторяются");
            }
        }
        int[] linetwo = new int[size];
        int f = 0;
        for (int a = 0; a < size; a = a + (int) Math.sqrt(size)) {
            for (int b = 0; b < size; b = b + (int) Math.sqrt(size)) {
                f = 0;
                for (int c = a; c < (int) Math.sqrt(size) + a; c++) {
                    for (int d = b; d < (int) Math.sqrt(size) + b; d++) {
                        linetwo[f] = board[c][d];
                        f++;
                    }
                }
                for (int g = 0; g < size; g++) {
                    for (int h = 0; h < size; h++)
                        if (linetwo[g] == linetwo[h] && g != h)
                            System.err.println("Таблица составлина некорректно: числа в квадратах повторяются");
                }
            }
        }

    }
}